# Maanya Tyagi — Portfolio

## Run it
Open `index.html` in a browser, or upload this folder to any static host (GitHub Pages, Netlify, Vercel). Internet is needed for Three.js (cdnjs) and Google Fonts.

## What it is
One self-contained page: portfolio sections plus a scroll-driven zoom-out from inside a neuron network to a rotating, pulsing brain.
- Backgrounds: four supplied micrograph images (embedded in index.html).
- 3D scene (neurons, signals, capillaries, blood flow, brain) is SIMULATED and drawn by code. It is not measured data or a scan. Captions on the page say so.

## To do before publishing
1. Confirm you may use each supplied image publicly and add credits.
2. Resume: put your PDF in `assets/resume/` and add a link like
   `<a class="btn" href="assets/resume/Maanya_Tyagi_AI_ML_Resume.pdf" download>Download Resume</a>` in the hero, nav, About and Contact sections. No PDF exists yet.
3. Photo: save to `assets/photos/` and replace the placeholder box (`.ph`) in About.
4. Real data: to use screenshots from the H01 human cortex dataset (Lichtman Lab, Harvard / Google; browse via Neuroglancer), save them in `assets/h01/` and check the dataset's terms and citation requirements first. Real brain mesh option: https://brainder.org/brain-for-blender (CC BY-SA 3.0).

## Editing content
All portfolio text is in the `D` object near the bottom of `index.html`.
